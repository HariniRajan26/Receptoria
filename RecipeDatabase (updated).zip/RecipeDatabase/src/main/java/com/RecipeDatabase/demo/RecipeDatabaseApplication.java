package com.RecipeDatabase.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeDatabaseApplication.class, args);
	}

}
